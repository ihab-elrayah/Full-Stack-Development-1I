require('dotenv').config();
const passport = require('passport');

require('./app_api/config/passport');