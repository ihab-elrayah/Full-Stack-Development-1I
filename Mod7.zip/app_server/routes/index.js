const ctrlMain = require('../controllers/main');
/* GET home page. */
router.get('/', ctrlMain.index)